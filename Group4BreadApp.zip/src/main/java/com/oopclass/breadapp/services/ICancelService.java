package com.oopclass.breadapp.services;

import com.oopclass.breadapp.models.Cancel;
import com.oopclass.breadapp.generic.GenericService;

/**
 * OOP Class 20-21
 * @author Gerald Villaran
 */

public interface ICancelService extends GenericService<Cancel> {

//	boolean authenticate(String email, String password);
//	
//	Item findByEmail(String email);
	
}
